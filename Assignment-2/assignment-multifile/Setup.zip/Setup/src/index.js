
import * as THREE from '../node_modules/three/build/three.module.js';
import {make_responsive} from './miscellaneous/MakeResponsive';

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera( 75, window.innerWidth / window.innerHeight, 0.1, 1000 );

const canvas = document.querySelector('#c');
const renderer = new THREE.WebGLRenderer({canvas});
//{canvas}renderer.setSize( window.innerWidth, window.innerHeight );

const geometry = new THREE.BoxGeometry();
const material = new THREE.MeshPhongMaterial({color: 0x44aa88});
const cube = new THREE.Mesh( geometry, material );
scene.add( cube );

camera.position.z = 5;


const color = 0xFFFFFF;
const intensity = 1;
const light = new THREE.DirectionalLight(color, intensity);
light.position.set(-1, 2, 4);
scene.add(light);


function animate() {
	requestAnimationFrame( animate );
	make_responsive(renderer, camera)	

	cube.rotation.x += 0.01;
	cube.rotation.y += 0.01;

	renderer.render( scene, camera );
};

animate();
